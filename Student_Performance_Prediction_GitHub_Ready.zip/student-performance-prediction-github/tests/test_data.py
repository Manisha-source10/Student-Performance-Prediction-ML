from src.generate_data import generate_dataset, FEATURES, TARGET


def test_dataset_shape_and_columns():
    df = generate_dataset(n_samples=100, random_state=7)
    assert len(df) == 100
    assert all(col in df.columns for col in FEATURES)
    assert TARGET in df.columns


def test_target_has_expected_categories():
    df = generate_dataset(n_samples=500, random_state=9)
    assert set(df[TARGET].unique()).issubset(
        {"Needs Support", "Moderate", "Good"}
    )


def test_numeric_ranges():
    df = generate_dataset(n_samples=200, random_state=11)
    assert df["attendance_pct"].between(0, 100).all()
    assert df["previous_marks_pct"].between(0, 100).all()
    assert df["study_hours_per_day"].between(0, 16).all()
