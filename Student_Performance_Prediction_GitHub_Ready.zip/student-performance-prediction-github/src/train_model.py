"""Train and compare classifiers on the synthetic demonstration dataset."""
from pathlib import Path
import json
import joblib
import matplotlib.pyplot as plt
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, classification_report, ConfusionMatrixDisplay,
    precision_recall_fscore_support
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "student_performance_synthetic.csv"
MODEL_DIR = ROOT / "models"
REPORT_DIR = ROOT / "reports"
FIGURE_DIR = REPORT_DIR / "figures"

FEATURES = [
    "attendance_pct",
    "previous_marks_pct",
    "assignment_completion_pct",
    "quiz_average_pct",
    "study_hours_per_day",
    "recent_marks_trend",
]
TARGET = "performance_category"


def build_models():
    logistic = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("classifier", LogisticRegression(max_iter=1500, class_weight="balanced",
                                          random_state=42)),
    ])
    forest = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("classifier", RandomForestClassifier(
            n_estimators=250, max_depth=8, min_samples_leaf=3,
            class_weight="balanced", random_state=42, n_jobs=-1
        )),
    ])
    return {"Logistic Regression": logistic, "Random Forest": forest}


def main():
    if not DATA_PATH.exists():
        from src.generate_data import main as generate
        generate()

    df = pd.read_csv(DATA_PATH)
    X, y = df[FEATURES], df[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    MODEL_DIR.mkdir(exist_ok=True)
    REPORT_DIR.mkdir(exist_ok=True)
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)

    results = {}
    fitted = {}
    for name, model in build_models().items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        precision, recall, f1, _ = precision_recall_fscore_support(
            y_test, pred, average="weighted", zero_division=0
        )
        results[name] = {
            "accuracy": round(float(accuracy_score(y_test, pred)), 4),
            "weighted_precision": round(float(precision), 4),
            "weighted_recall": round(float(recall), 4),
            "weighted_f1": round(float(f1), 4),
            "classification_report": classification_report(
                y_test, pred, output_dict=True, zero_division=0
            ),
        }
        fitted[name] = model

        fig, ax = plt.subplots(figsize=(6, 5))
        ConfusionMatrixDisplay.from_predictions(
            y_test, pred, ax=ax, cmap="Blues", colorbar=False
        )
        ax.set_title(f"{name} — synthetic test set")
        fig.tight_layout()
        fig.savefig(FIGURE_DIR / f"confusion_matrix_{name.lower().replace(' ', '_')}.png",
                    dpi=160)
        plt.close(fig)

    best_name = max(results, key=lambda key: results[key]["weighted_f1"])
    joblib.dump(fitted[best_name], MODEL_DIR / "best_model.joblib")

    summary = {
        "dataset": "Synthetic demonstration dataset; not real student records",
        "rows": int(len(df)),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "selected_model": best_name,
        "metrics": {
            name: {k: v for k, v in metric.items()
                   if k != "classification_report"}
            for name, metric in results.items()
        },
    }
    (REPORT_DIR / "metrics.json").write_text(json.dumps(summary, indent=2))

    metric_names = ["accuracy", "weighted_precision", "weighted_recall", "weighted_f1"]
    fig, ax = plt.subplots(figsize=(9, 5))
    x = range(len(metric_names))
    width = 0.35
    for i, (name, vals) in enumerate(results.items()):
        ax.bar([v + (i - 0.5) * width for v in x],
               [vals[m] for m in metric_names], width, label=name)
    ax.set_xticks(list(x), ["Accuracy", "Precision", "Recall", "F1-score"])
    ax.set_ylim(0, 1)
    ax.set_ylabel("Score")
    ax.set_title("Model comparison — synthetic test set")
    ax.legend()
    ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    fig.savefig(FIGURE_DIR / "model_comparison.png", dpi=160)
    plt.close(fig)

    print(f"Selected model: {best_name}")
    print(json.dumps(summary, indent=2))
    print(f"Saved model: {MODEL_DIR / 'best_model.joblib'}")


if __name__ == "__main__":
    main()
