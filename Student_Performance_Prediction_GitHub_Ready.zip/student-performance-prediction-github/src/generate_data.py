"""Generate a reproducible synthetic student-performance dataset."""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "student_performance_synthetic.csv"

FEATURES = [
    "attendance_pct",
    "previous_marks_pct",
    "assignment_completion_pct",
    "quiz_average_pct",
    "study_hours_per_day",
    "recent_marks_trend",
]
TARGET = "performance_category"


def generate_dataset(n_samples: int = 1800, random_state: int = 2026) -> pd.DataFrame:
    """Create synthetic records; no real student information is used."""
    rng = np.random.default_rng(random_state)

    attendance = rng.uniform(35, 100, n_samples)
    previous = rng.uniform(20, 100, n_samples)
    assignments = rng.uniform(15, 100, n_samples)
    quiz = rng.uniform(15, 100, n_samples)
    study = rng.uniform(0, 10, n_samples)
    trend = rng.uniform(-25, 25, n_samples)

    # A transparent synthetic scoring rule, not a learned ground truth.
    score = (
        0.20 * attendance
        + 0.24 * previous
        + 0.16 * assignments
        + 0.22 * quiz
        + 1.15 * study
        + 0.35 * trend
        + rng.normal(0, 9, n_samples)
    )
    score = np.clip(score, 0, 100)
    labels = np.where(score < 48, "Needs Support",
             np.where(score < 70, "Moderate", "Good"))

    frame = pd.DataFrame({
        "attendance_pct": attendance,
        "previous_marks_pct": previous,
        "assignment_completion_pct": assignments,
        "quiz_average_pct": quiz,
        "study_hours_per_day": study,
        "recent_marks_trend": trend,
        "performance_category": labels,
    })
    return frame.round({
        "attendance_pct": 1,
        "previous_marks_pct": 1,
        "assignment_completion_pct": 1,
        "quiz_average_pct": 1,
        "study_hours_per_day": 1,
        "recent_marks_trend": 1,
    })


def main() -> None:
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    data = generate_dataset()
    data.to_csv(DATA_PATH, index=False)
    print(f"Created {len(data)} synthetic records: {DATA_PATH}")


if __name__ == "__main__":
    main()
